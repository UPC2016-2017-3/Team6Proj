﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;

public partial class login : System.Web.UI.Page
{
    protected void btnOK_Click(object sender, EventArgs e)
    {
        string sqlstr = "Data Source=LENOVO-PC;Initial Catalog=AssetManageDB;Integrated Security=True";
        SqlConnection mycon = new SqlConnection(sqlstr);
        mycon.Open();
        string sql = "select * from Account where Userid='" + TextBox1.Text + "' and UserPassword='" + TextBox2.Text + "'";
        SqlCommand mycmd = new SqlCommand(sql, mycon);
        int num1 = Convert.ToInt32(mycmd.ExecuteScalar());
        mycon.Close();
        if (num1 > 0)
        {
            Response.Write("<script>alert('登录成功')</script>");
            Response.Redirect("homepage.aspx");
        }
        else
        {
            Response.Write("<script>alert('用户名或密码错误')</script>");
        }
        /*Response.Write("<script >alert('OK')</script>");
         Response.Redirect("homepage.aspx");
        */
        /*
        UserCon us = new UserCon();
       if(us.LoginDB(TextBox1.Text, TextBox2.Text))
        {
        }
        else{
        }
         * */
    }

}