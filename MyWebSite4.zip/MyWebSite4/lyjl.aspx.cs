﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class lyjl : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnCX_Click(object sender, EventArgs e)
    {
        String strCon = "Data Source=LENOVO-PC;Initial Catalog=AssetManageDB;Integrated Security=True";
        SqlConnection con = new SqlConnection(strCon);
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandText = "select * from Collect where CollectingWho='"+textlyr.Text+"'";

        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        adp.Fill(ds, "查询结果");
        GridView3.DataSource = ds;
        GridView3.DataMember = "查询结果";
        GridView3.DataBind();

    }
}