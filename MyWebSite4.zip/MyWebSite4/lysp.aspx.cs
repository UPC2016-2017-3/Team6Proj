﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class lysp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        /*String strCon = "Data Source=LENOVO-PC;Initial Catalog=AssetManageDB;Integrated Security=True";
        SqlConnection con = new SqlConnection(strCon);
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandText = "select*from Collect where CollectingState='" + text1.Text + "' ";
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        adp.Fill(ds, "查询结果");
        GridView1.DataSource = ds;
        GridView1.DataMember = "查询结果";
        GridView1.DataBind();*/
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        


       /* string tt1 = "审批";
        string sql = "update Collect set CollectingState=" + tt1 + " where CollectNum in('4','5')";

        String strCon = "Data Source=LENOVO-PC;Initial Catalog=AssetManageDB;Integrated Security=True";
        SqlConnection con = new SqlConnection(strCon);
        con.Open();
        SqlCommand cmd = new SqlCommand(sql,con);
        cmd.ExecuteNonQuery();
        con.Close();


        string sql="update Collect set CollectingState="审批"where CollectNum=4";
        Response.Write("<script>alert('审批成功!')</script>");
        Response.Redirect("lysp.aspx"); */
    }

  


    protected void Button3_Click(object sender, EventArgs e)
    {
        String strCon = "Data Source=LENOVO-PC;Initial Catalog=AssetManageDB;Integrated Security=True";
        SqlConnection con = new SqlConnection(strCon);
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandText = "Insert into test Values (6,'cc')";
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
    }
}