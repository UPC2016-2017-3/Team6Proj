﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class zcdj : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        String strCon = "Data Source=LENOVO-PC;Initial Catalog=AssetManageDB;Integrated Security=True";
        SqlConnection con = new SqlConnection(strCon);
        String strsql = "Insert Into InventoryTB(AssetID,AssetName,Itemize,Department,UserName,DocumentNum,BookValue,ResearchNum,Specifications,StoragePlace,AppropriationAccount,DirectionOfuse,AnnexNumber,AnnexPrice,AcquireDate,Remark)Values('" + textzcbh.Text + "','" + textzcmc.Text + "','" + zcfl.SelectedItem.Text + "','" + bumen.SelectedItem.Text + "','" + textsyr.Text + "','" + textdjh.Text + "','" + textdj.Text + "','" + textkyh.Text + "','" + textxh.Text + "','" + textcfdd.Text + "','" + textjfkm.Text + "','" + textsyfx.Text + "','" + textfjsl.Text + "','" + textfjzj.Text + "','" + textqdrq.Text + "','" + textbz.Text + "')";

        /*String strsql = "Insert Into InventoryTB(AssetID,AssetName,AssetClassificaton,Department,UserName,DocumentNum,BookValue,ResearchNum,Specifications,StoragePlace,AppropriationAccount,DirectionOfuse,AnnexNumber,AnnexName,AcquireDate,Remark)Values('" + textzcbh.Text + "','" + textzcmc.Text + "','" + zcfl.SelectedItem.Text + "','" + bumen.SelectedItem.Text + "','" + textsyr.Text + "','" + textdjh.Text + "','" + textdj.Text + "','" + textkyh.Text + "','" + textxh.Text + "','" + textcj.Text + "','" + textjfkm.Text + "','" + textsyfx.Text + "','" + textsyfx.Text + "','" + textfjsl.Text + "','" + textfjzj.Text + "','" + textqdrq.Text + "','" + textbz.Text + "')";*/
        SqlCommand cmd = new SqlCommand(strsql, con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Write("<script>alert('添加成功!')</script>");
        Response.Redirect("zcdj.aspx");
    }
}