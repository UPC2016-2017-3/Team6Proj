﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class lycx : System.Web.UI.Page
{
    protected void btn1_Click(object sender, EventArgs e)
    {
        String strCon = "Data Source=LENOVO-PC;Initial Catalog=AssetManageDB;Integrated Security=True";
        SqlConnection con = new SqlConnection(strCon);
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandText = "select*from InventoryTB where (Itemize='" + ddl1.Text + "' and  AssetName='" + text1.Text + "') or  (Itemize='" + ddl1.Text + "' and Username='" + text1.Text + "')";
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        adp.Fill(ds, "查询结果");
        GridView1.DataSource = ds;
        GridView1.DataMember = "查询结果";
        GridView1.DataBind();

    }
    protected void btn_Click(object sender, EventArgs e)
    {
        this.text1.Text = "";
        GridView1.DataSource = null;
        GridView1.DataBind();
    }
}