﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class pdhz : System.Web.UI.Page
{
    

    protected void btn3_Click(object sender, EventArgs e)
    {

    }
}