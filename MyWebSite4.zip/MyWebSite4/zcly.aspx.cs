﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class zcly : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn1_Click(object sender, EventArgs e)
    {
        String strCon = "Data Source=LENOVO-PC;Initial Catalog=AssetManageDB;Integrated Security=True";
        SqlConnection con = new SqlConnection(strCon);
        String strsql = "Insert Into Collect(DepartmentName,CollectingWho,AssetName,Itemize,AppropriationAccount,DirectionOfuse,CollectingNum)Values('" + DDL1.SelectedItem.Text + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + DropDownList1.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "')";
        SqlCommand cmd = new SqlCommand(strsql, con);
        con.Open();
        cmd.ExecuteNonQuery( );
        con.Close();
        /* message.Text = "已经成功添加资产信息，可查询具体信息";*/
        Response.Write("<script>alert('已经成功添加资产信息，可查询具体信息!')</script>");

    }
}